export AWS_PROFILE=aws-admin
export PATH=$HOME/bin:/usr/local/bin:$PATH
