# Enable Powerlevel10k instant prompt
# initialization code must go above this block
if [[ -r "$HOME/.cache/p10k-instant-prompt-${(%):-%n}.zsh" ]]; then
  source "$HOME/.cache/p10k-instant-prompt-${(%):-%n}.zsh"
fi

sources=(
  # edit ~/.p10k.zsh to configure p10k
  ~/.p10k.zsh
)

for f ($^sources(.N)) source $f
unset sources
